<!-- USERS LIST -->
  <div class="col-md-6">
      
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Your Categories</h3>
          <div class="box-tools pull-right">
            <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div><!-- /.box-header -->
        <div class="box-body">
          <div class="row">



            <div class="col-md-12">
              
                <ul class="chart-legend clearfix" >
                
                  <li><i class="fa fa-circle-o text-red"></i> Automobile</li>

                </ul>

            </div><!-- /.col -->


          </div><!-- /.row -->
        </div><!-- /.box-body -->
        <div class="box-footer">
          
            <li style="list-style:none;"> Sorted by the Manufacturers Association of Nigeria(MAN) Category definitions....</li>


        </div><!-- /.footer -->
      </div>

    </div>
