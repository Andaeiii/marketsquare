

	<div class="mxbox">	
			<div class="headx"> 
				<h1 class="headr">Thanks {{$fullname}} : <b>{{$email}}</b>!  </h1>
			</div>
			<div style="width:100%; height:300px; padding:20px;">
				we thank you for being a part of the transformation agenda... at Buynaija::Marketsquare
				<br>{{$msg}}
				<br/>
				<br/>
				<p style="display:block; width:100%;">
					For <b>Help</b> and <b>Support</b> please visit our HelpCenter at <a href="http://www.buynaija.com/support">Buynaija Support Center</a><br />
					Regards
				</p>				
			</div>					
			<div class="footxx">
				<b>	&copy;<?php echo date('Y'); ?> Buynaija.com</b><br />
				<span>For more information, visit <a href="http://www.buynaija.com/about">Buynaija.com</a>:: &copy; {{date('Y')}} BuyNaija :: TheMarketSquare..</span>
			</p>			
	</div>
	
	<style type="text/css">
		.mxbox{border:solid 3px #cccccc; width:700px; height:340px; overflow:hidden; position:relative; background-image:url(http://www.buynaija.com/assets/small.jpg); background-repeat:no-repeat; background-position:bottom right;}	
		*{font-family:Arial, Helvetica, sans-serif; font-size:12px;}
		h1{font-size:20px; font-weight:lighter !important;}
		a{text-decoration:none; color:#009999 !important;}
		.headx{width:100%; padding:10px; background-color:#B8E0E4;  border-bottom:dotted 1px #999999;}
		.headx, .headx b{font-size:17px; font-weight:normal; text-shadow:#fff 2px 2px 2px;}
		.footxx{position:absolute; bottom:0px; padding:10px 15px 5px; margin-top:20px; border-top:dotted 1px #CCCCCC; width:100%;}
		
		p{ line-height:20px; color: #666666;}
		.footxx span{display:block; }
		.footxx span, .footxx a{padding:5px 0px !important; color:#666666; font-size:11px;}
	</style>