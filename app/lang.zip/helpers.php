<?php
	
	//define constants... 
	define('DS', DIRECTORY_SEPARATOR); 

	function pr($ar, $bool=false){
		
		echo '<pre>';
		print_r($ar);
		echo '</pre>';
		
		if($bool){
			exit;
		}
		
	}
	

	function shortstr($str, $ct){
	
		$s = substr($str, 0, $ct);
		return $s . '....';
	
	}

	
	
	function resetAll(){
		//echo 'resettng';
	}
	
	
?>