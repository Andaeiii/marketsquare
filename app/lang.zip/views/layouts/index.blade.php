<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

<!-- Mirrored from vasterad.com/themes/trizzy/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 28 May 2016 23:18:39 GMT -->
<head>

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Trizzy</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="/css/style.css">
<link rel="stylesheet" href="/css/colors/green.css" id="colors">
 
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body class="boxed">
<div id="wrapper">


<!-- Top Bar
================================================== -->
<div id="top-bar">
	<div class="container">

		<!-- Top Bar Menu -->
		<div class="ten columns">
			<ul class="top-bar-menu">
				<li><i class="fa fa-phone"></i> (564) 123 4567</li>
				<li><i class="fa fa-envelope"></i> <a href="#">mail@example.com</a></li>
				<li>
					<div class="top-bar-dropdown">
						<span>English</span>
						<ul class="options">
							<li><div class="arrow"></div></li>
							<li><a href="#">English</a></li>
							<li><a href="#">Polish</a></li>
							<li><a href="#">Deutsch</a></li>
						</ul>
					</div>
				</li>
				<li>
					<div class="top-bar-dropdown">
						<span>USD</span>
						<ul class="options">
							<li><div class="arrow"></div></li>
							<li><a href="#">USD</a></li>
							<li><a href="#">PLN</a></li>
							<li><a href="#">EUR</a></li>
						</ul>
					</div>
				</li>
			</ul>
		</div>

		<!-- Social Icons -->
		<div class="six columns">
			<ul class="social-icons">
				<li><a class="facebook" href="#"><i class="icon-facebook"></i></a></li>
				<li><a class="twitter" href="#"><i class="icon-twitter"></i></a></li>
				<li><a class="dribbble" href="#"><i class="icon-dribbble"></i></a></li>
				<li><a class="gplus" href="#"><i class="icon-gplus"></i></a></li>
				<li><a class="pinterest" href="#"><i class="icon-pinterest"></i></a></li>
			</ul>
		</div>

	</div>
</div>

<div class="clearfix"></div>


<!-- Header
================================================== -->
<div class="container">


	<!-- Logo -->
	<div class="four columns">
		<div id="logo">
			<h1><a href="index-2.html"><img src="/images/logo.png" alt="Trizzy" /></a></h1>
		</div>
	</div>


	<!-- Additional Menu -->
	<div class="twelve columns">
		<div id="additional-menu">
			<ul>
				<li><a href="shopping-cart.html">Shopping Cart</a></li>
				<li><a href="wishlist.html">WishList <span>(2)</span></a></li>
				<li><a href="checkout-billing-details.html">Checkout</a></li>
				<li><a href="my-account.html">My Account</a></li>
			</ul>
		</div>
	</div>


	<!-- Shopping Cart -->
	<div class="twelve columns">

		<div id="cart">

			<!-- Button -->
			<div class="cart-btn">
				<a href="#" class="button adc">$178.00</a>
			</div>

			<div class="cart-list">

			<div class="arrow"></div>

				<div class="cart-amount">
					<span>2 items in the shopping cart</span>
				</div>

					<ul>
						<li>
							<a href="#"><img src="/images/small_product_list_08.jpg" alt="" /></a>
							<a href="#">Converse All Star Trainers</a>
							<span>1 x $79.00</span>
							<div class="clearfix"></div>
						</li>

						<li>
							<a href="#"><img src="/images/small_product_list_09.jpg" alt="" /></a>
							<a href="#">Tommy Hilfiger <br /> Shirt Beat</a>
							<span>1 x $99.00</span>
							<div class="clearfix"></div>
						</li>
					</ul>

				<div class="cart-buttons button">
					<a href="shopping-cart.html" class="view-cart" ><span data-hover="View Cart"><span>View Cart</span></span></a>
					<a href="checkout-billing-details.html" class="checkout"><span data-hover="Checkout">Checkout</span></a>
				</div>
				<div class="clearfix">

				</div>
			</div>

		</div>

		<!-- Search -->
		<nav class="top-search">
			<form action="#" method="get">
				<button><i class="fa fa-search"></i></button>
				<input class="search-field" type="text" placeholder="Search" value=""/>
			</form>
		</nav>

	</div>

</div>


<!-- Navigation
================================================== -->
<div class="container">
	<div class="sixteen columns">
		
		<a href="#menu" class="menu-trigger"><i class="fa fa-bars"></i> Menu</a>

		<nav id="navigation">
			<ul class="menu" id="responsive">

				<li><a href="index-2.html" class="current homepage" id="current">Home</a></li>

				<li class="dropdown">
					<a href="#">Shop</a>
					<ul>
						<li><a href="shop-with-sidebar.html">Shop With Sidebar</a></li>
						<li><a href="shop-full-width.html">Shop Full Width</a></li>
						<li><a href="checkout-billing-details.html">Checkout Pages</a></li>
						<li><a href="shop-categories-grid.html">Categories Grid</a></li>
						<li><a href="single-product-page.html">Single Product Page</a></li>
						<li><a href="variable-product-page.html">Variable Product Page</a></li>
						<li><a href="wishlist.html">Wishlist Page</a></li>
						<li><a href="shopping-cart.html">Shopping Cart</a></li>
					</ul>
				</li>


				<li>
					<a href="#">Features</a>
					<div class="mega">
						<div class="mega-container">

							<div class="one-column">
								<ul>
									<li><span class="mega-headline">Example Pages</span></li>
									<li><a href="contact.html">Contact</a></li>
									<li><a href="about.html">About Us</a></li>
									<li><a href="services.html">Services</a></li>
									<li><a href="faq.html">FAQ</a></li>
									<li><a href="404-page.html">404 Page</a></li>
								</ul>
							</div>

							<div class="one-column">
								<ul>
									<li><span class="mega-headline">Featured Pages</span></li>
									<li><a href="index-3.html">Business Homepage</a></li>
									<li><a href="shop-with-sidebar.html">Default Shop</a></li>
									<li><a href="blog-masonry.html">Masonry Blog</a></li>
									<li><a href="variable-product-page.html">Variable Product</a></li>
									<li><a href="portfolio-dynamic-grid.html">Dynamic Grid</a></li>
								</ul>
							</div>

							<div class="one-column hidden-on-mobile">
								<ul>
									<li><span class="mega-headline">Paragraph</span></li>
									<li><p>This <a href="#">Mega Menu</a> can handle everything. Lists, paragraphs, forms...</p></li>
								</ul>
							</div>

							<div class="one-fourth-column hidden-on-mobile">
								<a href="#" class="img-caption margin-reset">
									<figure>
										<img src="/images/menu-banner-01.jpg" alt="" />
										<figcaption>
											<h3>Jeans</h3>
											<span>Pack for Style</span>
										</figcaption>
									</figure>
								</a>
							</div>

							<div class="one-fourth-column hidden-on-mobile">
								<a href="#" class="img-caption margin-reset">
									<figure>
										<img src="/images/menu-banner-02.jpg" alt="" />
										<figcaption>
											<h3>Sunglasses</h3>
											<span>Nail the Basics</span>
										</figcaption>
									</figure>
								</a>
							</div>

							<div class="clearfix"></div>
						</div>
					</div>
				</li>


				<li class="dropdown">
					<a href="#">Shortcodes</a>
					<ul>
						<li><a href="elements.html">Elements</a></li>
						<li><a href="typography.html">Typography</a></li>
						<li><a href="pricing-tables.html">Pricing Tables</a></li>
						<li><a href="icons.html">Icons</a></li>
					</ul>
				</li>


				<li class="dropdown">
					<a href="#">Portfolio</a>
					<ul>
						<li><a href="portfolio-3-columns.html">3 Columns</a></li>
						<li><a href="portfolio-4-columns.html">4 Columns</a></li>
						<li><a href="portfolio-dynamic-grid.html">Dynamic Grid</a></li>
						<li><a href="single-project.html">Single Project</a></li>
					</ul>
				</li>
				

				<li class="dropdown">
					<a href="#">Blog</a>
					<ul>
						<li><a href="blog-standard.html">Blog Standard</a></li>
						<li><a href="blog-masonry.html">Blog Masonry</a></li>
						<li><a href="blog-single-post.html">Single Post</a></li>
					</ul>
				</li>


				<li class="demo-button">
				  <a href="#">Get This Theme</a>
				</li>

			</ul>
		</nav>
	</div>
</div>


<!-- Slider
================================================== -->
<div class="container fullwidth-element home-slider">

	<div class="tp-banner-container">
		<div class="tp-banner">
			<ul>
				<!-- Slide 1  -->
				<li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
					<img src="/images/slider.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
 					<div class="caption sfb fadeout" data-x="145" data-y="170" data-speed="400" data-start="800"  data-easing="Power4.easeOut">
						<h2>Dress Sharp</h2>
						<h3>Learn from the classics</h3>
						<a href="shop-with-sidebar.html" class="caption-btn">Shop The Collection</a>
					</div>
				</li>

				<!-- Slide 2  -->
				<li data-transition="zoomout" data-slotamount="7" data-masterspeed="1000">
 					<img src="/images/slider2.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
 					<div class="caption dark sfb fadeout" data-x="750" data-y="170" data-speed="400" data-start="800"  data-easing="Power4.easeOut">
						<h2>Urban Style</h2>
						<h3>Every cut and colour</h3>
						<a href="shop-with-sidebar.html" class="caption-btn">Shop The Collection</a>
					</div>
				</li>

				<!-- Slide 3  -->
				<li data-transition="fadetotopfadefrombottom" data-slotamount="7" data-masterspeed="1000">
 					<img src="/images/slider3.jpg"  alt="darkblurbg"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
 					<div class="caption dark sfb fadeout" data-x="850" data-y="170" data-speed="400" data-start="800"  data-easing="Power4.easeOut">
						<h2>New In</h2>
						<h3>Pants and T-Shirts</h3>
						<a href="shop-with-sidebar.html" class="caption-btn">Shop The Collection</a>
					</div>
				</li>

			</ul>
		</div>
	</div>
</div>


<!-- Featured
================================================== -->
<div class="container" >

	<div class="one-third column">
		<a href="#" class="img-caption" >
			<figure>
				<img src="/images/featured_img_1.jpg" alt="" />
				<figcaption>
					<h3>Men's Shirts</h3>
					<span>25% Off Summer Styles</span>
				</figcaption>
			</figure>
		</a>
	</div>

	<div class="one-third column">
		<a href="#" class="img-caption" >
			<figure>
				<img src="/images/featured_img_2.jpg" alt="" />
				<figcaption>
					<h3>Running Shoes</h3>
					<span>Sports Discount</span>
				</figcaption>
			</figure>
		</a>
	</div>

	<div class="one-third column">
		<a href="#" class="img-caption" >
			<figure>
				<img src="/images/featured_img_3.jpg" alt="" />
				<figcaption>
					<h3>Winter Jackets</h3>
					<span>End-of Season Sales</span>
				</figcaption>
			</figure>
		</a>
	</div>

</div>
<div class="clearfix"></div>


<!-- New Arrivals
================================================== -->
<div class="container">

	<!-- Headline -->
	<div class="sixteen columns">
		<h3 class="headline">New Arrivals</h3>
		<span class="line margin-bottom-0"></span>
	</div>

	<!-- Carousel -->
	<div id="new-arrivals" class="showbiz-container sixteen columns" >

		<!-- Navigation -->
		<div class="showbiz-navigation">
			<div id="showbiz_left_1" class="sb-navigation-left"><i class="fa fa-angle-left"></i></div>
			<div id="showbiz_right_1" class="sb-navigation-right"><i class="fa fa-angle-right"></i></div>
		</div>
		<div class="clearfix"></div>

		<!-- Products -->
		<div class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1" >
			<div class="overflowholder">

				<ul>

					<!-- Product #1 -->
					<li>
						<figure class="product">
							<div class="mediaholder">
								<a href="variable-product-page.html">
									<img alt="" src="/images/shop_item_01.jpg"/>
									<div class="cover">
										<img alt="" src="/images/shop_item_01_hover.jpg"/>
									</div>
								</a>
								<a href="#" class="product-button"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
							</div>

							<a href="variable-product-page.html">
								<section>
									<span class="product-category">Skirts</span>
									<h5>Brown Mini Skirt</h5>
									<span class="product-price">$79.00</span>
								</section>
							</a>
						</figure>
					</li>


					<!-- Product #2 -->
					<li>
						<figure class="product">
							<div class="mediaholder">
								<a href="variable-product-page.html">
									<img alt="" src="/images/shop_item_02.jpg"/>
									<div class="cover">
										<img alt="" src="/images/shop_item_02_hover.jpg"/>
									</div>
								</a>
								<a href="#" class="product-button"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
							</div>

							<a href="variable-product-page.html">
								<section>
									<span class="product-category">Shoes</span>
									<h5>Glory High Shoes</h5>
									<span class="product-price">$99.00</span>
								</section>
							</a>
						</figure>
					</li>


					<!-- Product #3 -->
					<li>
						<figure class="product">
							<div class="product-discount">SALE</div>
							<div class="mediaholder">
								<a href="single-product-page.html">
									<img alt="" src="/images/shop_item_03.jpg"/>
									<div class="cover">
										<img alt="" src="/images/shop_item_03_hover.jpg"/>
									</div>
								</a>
								<a href="#" class="product-button"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
							</div>

							<a href="single-product-page.html">
								<section>
									<span class="product-category">Suits</span>
									<h5>Wool Two-Piece Suit</h5>
									<span class="product-price-discount">$499.00<i>$399.00</i></span>
								</section>
							</a>
						</figure>
					</li>


					<!-- Product #4 -->
					<li>
						<figure class="product">
							<div class="mediaholder">
								<a href="variable-product-page.html">
									<img alt="" src="/images/shop_item_04.jpg"/>
									<div class="cover">
										<img alt="" src="/images/shop_item_04_hover.jpg"/>
									</div>
								</a>
								<a href="#" class="product-button"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
							</div>

							<a href="variable-product-page.html">
								<section>
									<span class="product-category">Longsleeves</span>
									<h5>Vintage Stripe Jumper</h5>
									<span class="product-price">$49.00</span>
								</section>
							</a>
						</figure>
					</li>


					<!-- Product #5 -->
					<li>
						<figure class="product">
							<div class="mediaholder">
								<a href="single-product-page.html">
									<img alt="" src="/images/shop_item_05.jpg"/>
									<div class="cover">
										<img alt="" src="/images/shop_item_05_hover.jpg"/>
									</div>
								</a>
								<a href="#" class="product-button"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
							</div>

							<a href="singlee-product-page.html">
								<section>
									<span class="product-category">Accessories</span>
									<h5>Vintage Sunglasses</h5>
									<span class="product-price">$29.00</span>
								</section>
							</a>
						</figure>
					</li>


					<!-- Product #6 -->
					<li>
						<figure class="product">
							<div class="mediaholder">
								<a href="single-product-page.html">
									<img alt="" src="/images/shop_item_06.jpg"/>
									<div class="cover">
										<img alt="" src="/images/shop_item_06_hover.jpg"/>
									</div>
								</a>
								<a href="#" class="product-button"><i class="fa fa-shopping-cart"></i> Add to Cart</a>
							</div>

							<a href="single-product-page.html">
								<section>
									<span class="product-category">Shirts</span>
									<h5>Solid Blue Polo Shirt</h5>
									<span class="product-price">$29.00</span>
								</section>
							</a>
						</figure>
					</li>

				</ul>
				<div class="clearfix"></div>

			</div>
			<div class="clearfix"></div>
		</div>
	</div>

</div>


<!-- Parallax Banner
================================================== -->
<div class="parallax-banner fullwidth-element"  data-background="#000" data-opacity="0.45" data-height="200">
	<img src="/images/parallax.jpg" alt="" />
	<div class="parallax-overlay"></div>
	<div class="parallax-title">End of season sale <span>Up to 35% off Women’s Denim</span></div>
</div>


<!-- Product Lists
================================================== -->
<div class="container margin-bottom-25">

	<!-- Best Sellers -->
	<div class="one-third column">

		<!-- Headline -->
		<h3 class="headline">Best Sellers</h3>
		<span class="line margin-bottom-0"></span>
		<div class="clearfix"></div>


		<ul class="product-list">

			<li><a href="#">
				<img src="/images/small_product_list_01.jpg" alt="" />
				<div class="product-list-desc">Canvas Backpack <i>$59.00</i></div>
			</a></li>

			<li><a href="#">
				<img src="/images/small_product_list_02.jpg" alt="" />
				<div class="product-list-desc">Long Sleeve Shirt <i>$29.00</i></div>
			</a></li>

			<li><a href="#">
				<img src="/images/small_product_list_03.jpg" alt="" />
				<div class="product-list-desc">Tommy Hilfiger Shirt Beat <i>$89.00</i></div>
			</a></li>

			<li><div class="clearfix"></div></li>

		</ul>

	</div>


	<!-- Top Rated -->
	<div class="one-third column">

		<!-- Headline -->
		<h3 class="headline">Top Rated</h3>
		<span class="line margin-bottom-0"></span>
		<div class="clearfix"></div>


		<ul class="product-list top-rated">

			<li><a href="#">
				<img src="/images/small_product_list_04.jpg" alt="" />
				<div class="product-list-desc with-rating">Brogue Boots in Leather <i>$99.00</i>
					<div class="rating five-stars">
						<div class="star-rating"></div>
						<div class="star-bg"></div>
					</div>
				</div>
			</a></li>

			<li><a href="#">
				<img src="/images/small_product_list_05.jpg" alt="" />
				<div class="product-list-desc with-rating">Slim Jeans With Blue Tint <i>$79.00</i>
					<div class="rating four-stars">
						<div class="star-rating"></div>
						<div class="star-bg"></div>
					</div>
				</div>
			</a></li>

			<li><a href="#">
				<img src="/images/small_product_list_06.jpg" alt="" />
				<div class="product-list-desc with-rating">New Look Fairisle Scarf <i>$19.00</i>
					<div class="rating three-stars">
						<div class="star-rating"></div>
						<div class="star-bg"></div>
					</div>
				</div>
			</a></li>

			<li><div class="clearfix"></div></li>

		</ul>

	</div>


	<!-- Weekly Sales -->
	<div class="one-third column">

		<!-- Headline -->
		<h3 class="headline">Weekly Sales</h3>
		<span class="line margin-bottom-0"></span>
		<div class="clearfix"></div>


		<ul class="product-list discount">

			<li><a href="#">
				<img src="/images/small_product_list_07.jpg" alt="" />
				<div class="product-list-desc">Short Sleeve Polo Shirt <i>$29.00<b>$19.00</b></i></div>
			</a></li>

			<li><a href="#">
				<img src="/images/small_product_list_08.jpg" alt="" />
				<div class="product-list-desc">Long Sleeve Shirt <i>$99.00<b>$79.00</b></i></div>
			</a></li>

			<li><a href="#">
				<img src="/images/small_product_list_09.jpg" alt="" />
				<div class="product-list-desc">Tommy Hilfiger Shirt Beat <i>$499.00<b>$399.00</b></i></div>
			</a></li>

			<li><div class="clearfix"></div></li>

		</ul>

	</div>

</div>
<div class="clearfix"></div>


<!-- Latest Articles
================================================== -->
<div class="container" >

	<!-- Headline -->
	<div class="sixteen columns" >
		<h3 class="headline">Latest Articles</h3>
		<span class="line margin-bottom-30"></span>
	</div>

	<!-- Post #1 -->
	<div class="four columns">
		<article class="from-the-blog">

			<figure class="from-the-blog-image">
				<a href="blog-single-post.html"><img src="/images/from_the_blog_01.jpg" alt="" /></a>
				<div class="hover-icon"></div>
			</figure>

			<section class="from-the-blog-content">
				<a href="blog-single-post.html"><h5>Amazon Raises Threshold for Free Shipping</h5></a>
				<i>By Vasterad on May 31, 2014</i>
				<span>Pellentesque ultricies vehicula eleifend. Aenean eu nunc semper faucibus sapien viverra.</span>
				<a href="blog-single-post.html" class="button gray">Read More</a>
			</section>

		</article>
	</div>

	<!-- Post #2 -->
	<div class="four columns">
		<article class="from-the-blog">

			<figure class="from-the-blog-image">
				<a href="blog-single-post.html"><img src="/images/from_the_blog_02.jpg" alt="" /></a>
				<div class="hover-icon"></div>
			</figure>

			<section class="from-the-blog-content">
				<a href="blog-single-post.html"><h5>How To Read The Symbols on Your Clothing Tags</h5></a>
				<i>By Vasterad on May 16, 2014</i>
				<span>Morbi quis magna nec lacus nunc eratu pharetra lorem sed sapien velit adipiscing. </span>
				<a href="blog-single-post.html" class="button gray">Read More</a>
			</section>

		</article>
	</div>

	<!-- Post #3 -->
	<div class="four columns">
		<article class="from-the-blog">

			<figure class="from-the-blog-image">
				<a href="blog-single-post.html"><img src="/images/from_the_blog_03.jpg" alt="" /></a>
				<div class="hover-icon"></div>
			</figure>

			<section class="from-the-blog-content">
				<a href="blog-single-post.html"><h5>Online Shopping Hit New Highs on Mobile Sales</h5></a>
				<i>By Vasterad on May 10, 2014</i>
				<span>Donec non egestas nisl. Aliquam tincidunt sem sed nisl dictum. Fusce gravida arius gravida.</span>
				<a href="blog-single-post.html" class="button gray">Read More</a>
			</section>

		</article>
	</div>

	<!-- Post #4 -->
	<div class="four columns">
		<article class="from-the-blog">

			<figure class="from-the-blog-image">
				<a href="blog-single-post.html"><img src="/images/from_the_blog_04.jpg" alt="" /></a>
				<div class="hover-icon"></div>
			</figure>

			<section class="from-the-blog-content">
				<a href="blog-single-post.html"><h5>How to Choose Size - Does Your Shirt Fit Properly?</h5></a>
				<i>By Vasterad on April 20, 2014</i>
				<span>Nullam eget ante cursus, dignissim velit sit amet, tempus massa bibendum venenatis.</span>
				<a href="blog-single-post.html" class="button gray">Read More</a>
			</section>

		</article>
	</div>

</div>

<div class="margin-top-50"></div>

<!-- Footer
================================================== -->
<div id="footer">

	<!-- Container -->
	<div class="container">

		<div class="four columns">
			<img src="/images/logo-footer.png" alt="" class="margin-top-10"/>
			<p class="margin-top-15">Nulla facilisis feugiat magna, ut molestie metus hendrerit vitae. Vivamus tristique lectus at varius rutrum. Integer lobortis mauris non consectetur eleifend.</p>
		</div>

		<div class="four columns">

			<!-- Headline -->
			<h3 class="headline footer">Customer Service</h3>
			<span class="line"></span>
			<div class="clearfix"></div>

			<ul class="footer-links">
				<li><a href="#">Order Status</a></li>
				<li><a href="#">Payment Methods</a></li>
				<li><a href="#">Delivery & Returns</a></li>
				<li><a href="#">Privacy Policy</a></li>
				<li><a href="#">Terms & Conditions</a></li>
			</ul>

		</div>

		<div class="four columns">

			<!-- Headline -->
			<h3 class="headline footer">My Account</h3>
			<span class="line"></span>
			<div class="clearfix"></div>

			<ul class="footer-links">
				<li><a href="#">My Account</a></li>
				<li><a href="#">Order History</a></li>
				<li><a href="#">Wish List</a></li>
			</ul>

		</div>

		<div class="four columns">

			<!-- Headline -->
			<h3 class="headline footer">Newsletter</h3>
			<span class="line"></span>
			<div class="clearfix"></div>
			<p>Sign up to receive email updates on new product announcements, gift ideas, special promotions, sales and more.</p>

			<form action="#" method="get">
				<button class="newsletter-btn" type="submit">Join</button>
				<input class="newsletter" type="text" placeholder="mail@example.com" value=""/>
			</form>
		</div>

	</div>
	<!-- Container / End -->

</div>
<!-- Footer / End -->

<!-- Footer Bottom / Start -->
<div id="footer-bottom">

	<!-- Container -->
	<div class="container">

		<div class="eight columns">© Copyright 2014 by <a href="#">trizzy</a>. All Rights Reserved.</div>
		<div class="eight columns">
			<ul class="payment-icons">
				<li><img src="/images/visa.png" alt="" /></li>
				<li><img src="/images/mastercard.png" alt="" /></li>
				<li><img src="/images/skrill.png" alt="" /></li>
				<li><img src="/images/moneybookers.png" alt="" /></li>
				<li><img src="/images/paypal.png" alt="" /></li>
			</ul>
		</div>

	</div>
	<!-- Container / End -->

</div>
<!-- Footer Bottom / End -->

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

</div>


<!-- Java Script
================================================== -->
<script src="/scripts/jquery-1.11.0.min.js"></script>
<script src="/scripts/jquery-migrate-1.2.1.min.js"></script>
<script src="/scripts/jquery.jpanelmenu.js"></script>
<script src="/scripts/jquery.themepunch.plugins.min.js"></script>
<script src="/scripts/jquery.themepunch.revolution.min.js"></script>
<script src="/scripts/jquery.themepunch.showbizpro.min.js"></script>
<script src="/scripts/jquery.magnific-popup.min.js"></script>
<script src="/scripts/hoverIntent.js"></script>
<script src="/scripts/superfish.js"></script>
<script src="/scripts/jquery.pureparallax.js"></script>
<script src="/scripts/jquery.pricefilter.js"></script>
<script src="/scripts/jquery.selectric.min.js"></script>
<script src="/scripts/jquery.royalslider.min.js"></script>
<script src="/scripts/SelectBox.js"></script>
<script src="/scripts/modernizr.custom.js"></script>
<script src="/scripts/waypoints.min.js"></script>
<script src="/scripts/jquery.flexslider-min.js"></script>
<script src="/scripts/jquery.counterup.min.js"></script>
<script src="/scripts/jquery.tooltips.min.js"></script>
<script src="/scripts/jquery.isotope.min.js"></script>
<script src="/scripts/puregrid.js"></script>
<script src="/scripts/stacktable.js"></script>
<script src="/scripts/custom.js"></script>


<!-- Style Switcher
================================================== -->
<script src="scripts/switcher.js"></script>

<div id="style-switcher">
	<h2>Style Switcher <a href="#"></a></h2>
	
	<div><h3>Predefined Colors</h3>
		<ul class="colors" id="color1">
			<li><a href="#" class="green" title="Green"></a></li>
			<li><a href="#" class="blue" title="Blue"></a></li>
			<li><a href="#" class="orange" title="Orange"></a></li>
			<li><a href="#" class="navy" title="Navy"></a></li>
			<li><a href="#" class="yellow" title="Yellow"></a></li>
			<li><a href="#" class="peach" title="Peach"></a></li>
			<li><a href="#" class="beige" title="Beige"></a></li>
			<li><a href="#" class="purple" title="Purple"></a></li>
			<li><a href="#" class="celadon" title="Celadon"></a></li>
			<li><a href="#" class="pink" title="Pink"></a></li>
			<li><a href="#" class="red" title="Red"></a></li>
			<li><a href="#" class="brown" title="Brown"></a></li>
			<li><a href="#" class="cherry" title="Cherry"></a></li>
			<li><a href="#" class="cyan" title="Cyan"></a></li>
			<li><a href="#" class="gray" title="Gray"></a></li>
			<li><a href="#" class="darkcol" title="Dark"></a></li>
		</ul>
		
		<h3>Layout Style</h3>
		<div class="layout-style">
			<select id="layout-style"> 
				<option value="1">Boxed</option>
				<option value="2">Wide</option>
			</select>
		</div>
	
	<h3>Background Image</h3>
		 <ul class="colors bg" id="bg">
			<li><a href="#" class="bg1"></a></li>
			<li><a href="#" class="bg2"></a></li>
			<li><a href="#" class="bg3"></a></li>
			<li><a href="#" class="bg4"></a></li>
			<li><a href="#" class="bg5"></a></li>
			<li><a href="#" class="bg6"></a></li>
			<li><a href="#" class="bg7"></a></li>
			<li><a href="#" class="bg8"></a></li>
			<li><a href="#" class="bg9"></a></li>
			<li><a href="#" class="bg10"></a></li>
			<li><a href="#" class="bg11"></a></li>
			<li><a href="#" class="bg12"></a></li>
			<li><a href="#" class="bg13"></a></li>
			<li><a href="#" class="bg14"></a></li>
			<li><a href="#" class="bg15"></a></li>
			<li><a href="#" class="bg16"></a></li>
		</ul>
		
	<h3>Background Color</h3>
		<ul class="colors bgsolid" id="bgsolid">
			<li><a href="#" class="green-bg" title="Green"></a></li>
			<li><a href="#" class="blue-bg" title="Blue"></a></li>
			<li><a href="#" class="orange-bg" title="Orange"></a></li>
			<li><a href="#" class="navy-bg" title="Navy"></a></li>
			<li><a href="#" class="yellow-bg" title="Yellow"></a></li>
			<li><a href="#" class="peach-bg" title="Peach"></a></li>
			<li><a href="#" class="beige-bg" title="Beige"></a></li>
			<li><a href="#" class="purple-bg" title="Purple"></a></li>
			<li><a href="#" class="red-bg" title="Red"></a></li>
			<li><a href="#" class="pink-bg" title="Pink"></a></li>
			<li><a href="#" class="celadon-bg" title="Celadon"></a></li>
			<li><a href="#" class="brown-bg" title="Brown"></a></li>
			<li><a href="#" class="cherry-bg" title="Cherry"></a></li>
			<li><a href="#" class="cyan-bg" title="Cyan"></a></li>
			<li><a href="#" class="gray-bg" title="Gray"></a></li>
			<li><a href="#" class="dark-bg" title="Dark"></a></li>
		</ul>
	</div>
	
	<div id="reset"><a href="#" class="button color">Reset</a></div>
		
</div>


</body>

<!-- Mirrored from vasterad.com/themes/trizzy/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 28 May 2016 23:23:46 GMT -->
</html>