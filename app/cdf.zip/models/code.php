<?php 

	class Code extends Basemodel{
		


		public static $rules = array(
			'vcode' => 'required'
		);

	}